#!python
# coding: utf-8

"""
See :mod:`can.player`.
"""

from __future__ import absolute_import

from can.player import main


if __name__ == "__main__":
    main()
